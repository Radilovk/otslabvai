export default {
  testEnvironment: 'node'
};
